var appControllers = angular.module('zwilling.controllers',[]); //Use for all controller of application
var appServices = angular.module('zwilling.services',[]); //Use for all services of application