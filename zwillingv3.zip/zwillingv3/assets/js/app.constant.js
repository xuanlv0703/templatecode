'use strict'
app.constant('ENV',{
    domain : 'http://zwilling.local:8888/index.cfm/',
   api:'api/v1'
});