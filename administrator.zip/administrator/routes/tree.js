'use strict';

const router            = require('express').Router();
const Tree              = require('../models/tree.js');
const Part              = require('../models/part.js');
const Util         = require('../util/util.js');
const routesVersioning  = require('express-routes-versioning')();
const uuid              = require('node-uuid');
var async = require("async");
module.exports = treeAPI;

function treeAPI(app) {
    const dbconnection = app.get('dbpool');
    const version = app.get('version');

    router.route('/')
    .get(routesVersioning({[version.v1]: getAllV1}, Util.NoMatchFoundCallback))  
    .post(routesVersioning({[version.v1]: createV1}, Util.NoMatchFoundCallback))  

    router.route('/:id')
    .get(routesVersioning({[version.v1]: getDetailV1}, Util.NoMatchFoundCallback))  
    .put(routesVersioning({[version.v1]: updateV1}, Util.NoMatchFoundCallback))  
    .delete(routesVersioning({[version.v1]: deleteV1}, Util.NoMatchFoundCallback))  

    router.route('/:id/component/:lang')
    .get(routesVersioning({[version.v1]: listbytreeoflangV1}, Util.NoMatchFoundCallback))  

     router.route('/:id/component/part/:lang')
    .get(routesVersioning({[version.v1]: listbytreepartoflangV1}, Util.NoMatchFoundCallback))  

    router.route('/:id/component')
    .post(routesVersioning({[version.v1]: savetreecomponent}, Util.NoMatchFoundCallback))  

    function listbytreeoflangV1(req,res){
    	var id = req.params.id;
        var lang = req.params.lang;
        
        Tree.listbytreeoflang(id,lang,dbconnection,function(err,data){
            var roots = Util.renderTree(data);
            res.jsonp(Util.apiMessage(err, roots))
        })
    }

    function listbytreepartoflangV1(req,res){
        var id = req.params.id;
        var lang = req.params.lang;
        
        Tree.listbytreeoflang(id,lang,dbconnection,function(err,data){

            // for(var i = 0;i<data.length;i++){
            //     var component_id = data[i].component_id;
            //     var j = 0;
            //     Part.getpartbycomponentbylang(component_id,lang,dbconnection,function(err,res){
            //         if(res.length >0){
            //             data[j].part=res;
            //         }
            //         j++;
            //     })
            // }

            // console.log('data:',data)

            var list = [];

            // 1st para in async.each() is the array of items
            async.each(data,
              // 2nd param is the function that each item is passed to
              function(item, callback){
                // Call an asynchronous function, often a save() to DB
                  // Async call is done, alert via callback
                  var component_id = item.component_id;
                  Part.getpartbycomponentbylang(component_id,lang,dbconnection,function(err,res){
                    if(res.length >0){
                        item.part=res;
                    }
                    list.push(item);
                    callback()
                        
                  })
              },
              // 3rd param is the function to call when everything's done
              function(err){
                // console.log('DATA',data)
                // All tasks are done now
                var roots = Util.renderTreePart(list);
                res.jsonp(Util.apiMessage(err, roots));
              }
            );

          
        })
    }

    function savetreecomponent(req,res){
      var tree_id = req.params.id;
      var tree = req.body;
      var obj = convertTreeToList(tree);
        Tree.create(tree_id,obj,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }

    // scroll to bottom
function convertTreeToList(root) {
    var stack = [], array = [], hashMap = {};

     for(var i = root.length - 1; i >= 0; i--) {
                stack.push(root[i]);
            }
    while(stack.length !== 0) {
        var node = stack.pop();
        if(node.children === null || node.children.length==0) {
            visitNode(node, hashMap, array);
        } else {

            for(var i = node.children.length - 1; i >= 0; i--) {
                stack.push(node.children[i]);
            }
            node.children=[]
            visitNode(node, hashMap, array);
        }
    }

    return array;
}

function visitNode(node, hashMap, array) {
    // if(!hashMap[node.data]) {
    //     hashMap[node.data] = true;
        delete node.children;
        delete node.name;
        delete node.id;
        var arr = Object.keys(node).map(function (key) { return node[key]; });
        array.push(arr);
    // }
}
    function getDetailV1(req,res){
        var id = req.params.id;        
        Tree.findById(id,dbconnection,function(err,data){            
            res.jsonp(Util.apiMessage(err, data));
        })
    }

    function getAllV1(req,res){    
        Tree.find(dbconnection,function(err,data){            
            res.jsonp(Util.apiMessage(err, data));
        })
    }

    function createV1(req,res){    
        Tree.create(req.body, dbconnection,function(err,data){            
            res.jsonp(Util.apiMessage(err, data));
        })
    }

    function updateV1(req,res){    
        var id = req.params.id;        
        Tree.update(req.body, id, dbconnection,function(err,data){            
            res.jsonp(Util.apiMessage(err, data));
        })
    }

    function deleteV1(req,res){    
        var id = req.params.id;        
        Tree.delete(id, dbconnection,function(err,data){            
            res.jsonp(Util.apiMessage(err, data));
        })
    }

    return router
}