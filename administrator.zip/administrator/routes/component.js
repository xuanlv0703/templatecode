'use strict';

const router            = require('express').Router();
const Component              = require('../models/component.js');
const Util         = require('../util/util.js');
const routesVersioning  = require('express-routes-versioning')();
const uuid              = require('node-uuid');

module.exports = componentAPI;

function componentAPI(app) {
    const dbconnection = app.get('dbpool');
    const version = app.get('version');

    router.route('/')    
    .post(routesVersioning({[version.v1]: createV1},Util.NoMatchFoundCallback))

    router.route('/:id/language') 
    .post(routesVersioning({[version.v1]: createbylangV1},Util.NoMatchFoundCallback));

    router.route('/language/:language')
    .get(routesVersioning({[version.v1]: findByLangV1}, Util.NoMatchFoundCallback))

    router.route('/:id')
    .put(routesVersioning({[version.v1]: updateV1},Util.NoMatchFoundCallback))
    .delete(routesVersioning({[version.v1]: deleteV1},Util.NoMatchFoundCallback)); 

    function findByLangV1(req, res) {   
    	var lang = req.params.language;
        Component.findByLang(lang, dbconnection, function(err, data){                    
            res.jsonp(Util.apiMessage(err, data))
        })
    };



    function updateV1(req,res){
        var obj = req.body;
        Component.update(obj,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }

    function deleteV1(req,res){
        var id = req.params.id;
        Component.delete(id,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }


    function createV1(req,res){
        var obj = req.body;
        Component.create(obj,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }
    
    function createbylangV1(req,res){
        var obj = req.body;
        Component.createbylang(obj,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }

    return router
}