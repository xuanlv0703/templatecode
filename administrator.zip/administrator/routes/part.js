'use strict';

const router            = require('express').Router();
const Part              = require('../models/part.js');
const Util         = require('../util/util.js');
const routesVersioning  = require('express-routes-versioning')();
const uuid              = require('node-uuid');

module.exports = partAPI;

function partAPI(app) {

    const dbconnection = app.get('dbpool');
    const version = app.get('version');

    router.route('/')    
    .post(routesVersioning({[version.v1]: createV1},Util.NoMatchFoundCallback))

    router.route('/:id/language') 
    .post(routesVersioning({[version.v1]: createbylangV1},Util.NoMatchFoundCallback));

    router.route('/language/:language')
    .get(routesVersioning({[version.v1]: findByLangV1}, Util.NoMatchFoundCallback))

    router.route('/:id')
    .put(routesVersioning({[version.v1]: updateV1},Util.NoMatchFoundCallback))
    .delete(routesVersioning({[version.v1]: deleteV1},Util.NoMatchFoundCallback)); 

    function findByLangV1(req, res) {   
    	var lang = req.params.language
       
        Part.findByLang(lang, dbconnection, function(err, data){                    
            res.jsonp(Util.apiMessage(err, data))
        })
    };

    function updateV1(req,res){
        var obj = req.body;
        Part.update(obj,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }

    function deleteV1(req,res){
        var id = req.params.id;
        var language = req.body.language;
        var component_id = req.body.component_id;     
        Part.delete(id, language, component_id, dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }


    function createV1(req,res){
        var obj = req.body;
        Part.create(obj,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }
    
    function createbylangV1(req,res){
        var obj = req.body;
        Part.createbylang(obj,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }

    return router
}