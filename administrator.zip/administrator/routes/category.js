'use strict';

const router            = require('express').Router();
const Category              = require('../models/category.js');
const Util         = require('../util/util.js');
const routesVersioning  = require('express-routes-versioning')();
const uuid              = require('node-uuid');

module.exports = categoryAPI;

function categoryAPI(app) {
    const dbconnection = app.get('dbpool');
    const version = app.get('version');

    router.route('/')
    .get(routesVersioning({[version.v1]: findV1}, Util.NoMatchFoundCallback))  
    .post(routesVersioning({[version.v1]: createV1},Util.NoMatchFoundCallback));

     router.route('/:id/lang') 
    .post(routesVersioning({[version.v1]: createbylangV1},Util.NoMatchFoundCallback));

    router.route('/:id')
    .put(routesVersioning({[version.v1]: updateV1},Util.NoMatchFoundCallback))
    .delete(routesVersioning({[version.v1]: deleteV1},Util.NoMatchFoundCallback));

    router.route('/lang/:lang')
    .get(routesVersioning({[version.v1]: listbylangV1}, Util.NoMatchFoundCallback))  


    function findV1(req, res) {        
       Category.find(dbconnection, function(err, data){        
            var roots = Util.renderTree(data);
            res.jsonp(Util.apiMessage(err, roots))
        })
    };

    function createV1(req,res){
        var obj = req.body;
        Category.create(obj,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }

    function updateV1(req,res){
        var obj = req.body;
        Category.update(obj,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }

    function deleteV1(req,res){
        var id = req.params.id;
        Category.delete(id,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }

    function listbylangV1(req,res){
        var lang = req.params.lang;
        Category.listbylang(lang,dbconnection,function(err,data){
            var roots = Util.renderTree(data);
            res.jsonp(Util.apiMessage(err, roots))
        })
    }

       function createbylangV1(req,res){
        var obj = req.body;
        Category.createbylang(obj,dbconnection,function(err,data){
            res.jsonp(Util.apiMessage(err, data))
        })
    }

    return router
}