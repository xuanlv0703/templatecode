exports.apiMessage = function(err, data) {
    var message = {
        "error": !!err,
        "message": err ? "Error executing query" : "Success"
    };
    if (!err && data) message.data = data;
    return message
}

exports.NoMatchFoundCallback = function(req,res){
	var message = {"error": true,"message": "version not found"};
	res.jsonp(message);
}

exports.errorMessage = function(){
	var message = {"error": true,"message": "Error executing query", "data" : []};
	return message;
}

exports.renderTree = function(nodes){
    nodes.sort(compare);
   var map = {}, node, roots = [];
        for (var i = 0; i < nodes.length; i += 1) {
            node = nodes[i];
            node.children = [];
            map[node.id] = i; // use map to look-up the parents
            if (node.parent_id !== 0) {
                nodes[map[node.parent_id]].children.push(node);
            } else {

                roots.push(node);
            }
        }
    return roots;
}

function compare(a,b) {
  if (a.parent_id < b.parent_id)
    return -1;
  if (a.parent_id > b.parent_id)
    return 1;
  return 0;
}

exports.renderTreePart = function(nodes){
    nodes.sort(compare);
   var map = {}, node, roots = [];
        for (var i = 0; i < nodes.length; i += 1) {
            node = nodes[i];
            node.children = [];
            map[node.id] = i; // use map to look-up the parents
            if (node.parent_id !== 0) {

                nodes[map[node.parent_id]].children.push(node);
            } else {
                roots.push(node);
            }
        }
    return roots;
}
