'use strict';

const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const config = require('./configs/config'); // get our config file
const morgan = require('morgan');
const jwt = require('jsonwebtoken'); // used to create, sign, and verify tokens

const app = express();
const port = config.api_port;
const pool = mysql.createPool(config['db_conn']['development']);

app.use(express.static(__dirname));
app.set('dbpool', pool);
app.set('jwt', jwt);
app.set('secret', config.secret);
app.set('version',config.version);

if(process.env.NODE_ENV !== 'test') {
    //use morgan to log at command line
    app.use(morgan('combined')); //'combined' outputs the Apache style LOGs
}

app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(bodyParser.json({ limit: '50mb' }));

//cross domain.
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type,Cache-Control,x-access-token,accept-version");
    if (req.method === 'OPTIONS') {
        res.statusCode = 204;
        return res.end();
    } else {
        return next();
    }
});

// app.use(function(req, res, next) {   
//    if(config.version.v1 != req.headers['accept-version']){
//         return res.jsonp({"Error": true,"Message": "version not found"});   
//    }
//    return next();
// });

// app.use(function(req, res, next) {
//     // check header or url parameters or post parameters for token
//     var token = req.body.token || req.param.token || req.headers['x-access-token'] || req.query.token;
    
//     if (req.url == '/api/user/login' || (req.url =='/api/user/' && req.method =='POST')) {
//         next();
//         return;
//     }

//     // decode token
//     if (token) {
//         // verifies secret and checks exp
//         jwt.verify(token, config.secret, function(err, decoded) {

//             if (err) {
//                 return res.status(403).send({
//                     Error: true,
//                     message: 'Failed to authenticate token or token expried.'
//                 });
//             } else {
//                 // if everything is good, save to request for use in other routes
//                 req.decoded = decoded;
//                 next();
//             }
//         });
//     } else {

//         // if there is no token
//         // return an error
//         return res.status(403).send({
//             Error: true,
//             message: 'No token provided.'
//         });
//     }
//});

// route registration
addApi({
    url:'category', 
    filename: 'category'
});

addApi({
    url:'component', 
    filename: 'component'
});

addApi({
    url:'part', 
    filename: 'part'
});

addApi({
    url:'tree', 
    filename: 'tree'
});

// app.use(function (err, req, res, next) {
//   console.error('xuanle',err.stack)
//     var receiverEmail = config.errormail;
//     var transporter = nodemailer.createTransport(config.servermail);
//     var text = err.stack;
//     var mailOptions = {
//         from: 'xuan@rasia.info', // sender address
//         to: receiverEmail, // list of receivers
//         subject: 'Error from Photo Hub Page', // Subject line
//         text: text //, // plaintext body
//         // html: '<b>Hello world ✔</b>' // You can choose to send an HTML body instead
//     };
//     transporter.sendMail(mailOptions, function(error, info){
//   res.status(500).send('Something broke!')

//     });
// })

app.listen(port, function() {
    console.log("All right ! I am alive at Port '" + port + "'.\nConnecting to database " + config.db_conn.development.host);
});

module.exports = app; // for testing

function addApi(node) {
  var url = '/api/' + node.url;
  var apijs = './routes/' + node.filename;
  // console.log('adding', require(apijs)(app).stack)
  require('./util/document')(url,require(apijs)(app).stack);
  app.use(url, require(apijs)(app));
}
