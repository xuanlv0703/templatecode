# TODO API

> A RESTful API by version built with Express to manage a lscomputer

### Getting Started

Make sure you have [Node.js](http://nodejs.org) and [NPM](http://npmjs.com) installed and follow the steps below:

Clone this repository

```bash
$ git clone 
```

Install the dependencies

```bash
$ cd path/to/api && npm install
```

Run the app:

```bash
$ npm start
```

Run test the app:

```bash
$ npm test
```


### API

<table>
      <thead>
        <tr>
          <th>Resource URL</th>
          <th>HTTP verb</th>
          <th>Description</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>/api/user</td>
          <td>GET</td>
          <td>Get all users</td>
        </tr>
        <tr>
          <td>/api/user/:id</td>
          <td>GET</td>
          <td>Get a single user</td>
        </tr>
        <tr>
          <td>/api/user</td>
          <td>POST</td>
          <td>Create a new user</td>
        </tr>
        <tr>
          <td>/api/user/:id</td>
          <td>PUT</td>
          <td>Update a user</td>
        </tr>
        <tr>
          <td>/api/user/:id</td>
          <td>DELETE</td>
          <td>Delete a user</td>
        </tr>
      </tbody>
</table>

### License

Copyright (c) 2017

Licensed under the [MIT license](LICENSE).
