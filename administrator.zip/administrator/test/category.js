process.env.NODE_ENV = 'test';

//Require the dev-dependencies
var chai = require('chai');
var chaiHttp = require('chai-http');
var server = require('../server');
var should = chai.should();
var token ='';

chai.use(chaiHttp);
/*
  * Test the /GET route
  */
  describe('/GET category by language', () => {
      it('it should GET category by language', (done) => {
        chai.request(server)
            .get('/api/category/lang/de_DE')
            .set('accept-version', '1.0.0')
            .end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('object');
                res.body.should.have.property('error').eql(false);;
              done();
            });
      });
  });

  /*
  * Test the /POST route
  */
  describe('/POST category', () => {
      it('it should POST create category', (done) => {
        var obj = {parent_id:0,display_order:1,name:"cate 1",language:'de_DE',description:'for testing'};
        chai.request(server)
            .post('/api/category')
            .set('accept-version', '1.0.0')
            .send(obj)
            .end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('object');
                res.body.should.have.property('error').eql(false);;
              done();
            });
      });
  });

    /*
  * Test the /PUT route
  */
  describe('/PUT category', () => {
      it('it should PUT update category', (done) => {
        var obj = {category_id:400,id:400,parent_id:0,display_order:1,name:"cate 1",language:'de_DE',description:'for testing'};
        chai.request(server)
            .put('/api/category/400')
            .set('accept-version', '1.0.0')
            .send(obj)
            .end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('object');
                res.body.should.have.property('error').eql(false);;
              done();
            });
      });
  });

      /*
  * Test the /DELETE route
  */
  describe('/DELETE category', () => {
      it('it should DELETE  category', (done) => {
        chai.request(server)
            .put('/api/category/400')
            .set('accept-version', '1.0.0')
            .end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('object');
                res.body.should.have.property('error').eql(false);;
              done();
            });
      });
  });



