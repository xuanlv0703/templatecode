process.env.NODE_ENV = 'test';

//Require the dev-dependencies
var chai = require('chai');
var chaiHttp = require('chai-http');
var server = require('../server');
var should = chai.should();
var token ='';

chai.use(chaiHttp);
/*
  * Test the /GET route
  */
  describe('/GET component', () => {
      it('it should GET all component by language', (done) => {
        chai.request(server)
            .get('/api/component/lang/de_DE')
            .set('accept-version', '1.0.0')
            .end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('object');
                res.body.should.have.property('error').eql(false);;
              done();
            });
      });
  });

  /*
  * Test the /POST route
  */
  describe('/POST component', () => {
      it('it should POST create component', (done) => {
        var obj = {display_order:0,name:"component 1",language:'de_DE'};
        chai.request(server)
            .post('/api/component')
            .set('accept-version', '1.0.0')
            .send(obj)
            .end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('object');
                res.body.should.have.property('error').eql(false);;
              done();
            });
      });
  });

  /*
  * Test the /PUT route
  */
  describe('/PUT component', () => {
      it('it should PUT update component', (done) => {
        var obj = {component_id:400,id:400,display_order:1,name:"cate 1",language:'de_DE'};
        chai.request(server)
            .put('/api/component/1')
            .set('accept-version', '1.0.0')
            .send(obj)
            .end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('object');
                res.body.should.have.property('error').eql(false);;
              done();
            });
      });
  });

      /*
  * Test the /DELETE route
  */
  describe('/DELETE component', () => {
      it('it should DELETE  component', (done) => {
        chai.request(server)
            .put('/api/component/1')
            .set('accept-version', '1.0.0')
            .end((err, res) => {
                res.should.have.status(200);
                res.body.should.be.a('object');
                res.body.should.have.property('error').eql(false);;
              done();
            });
      });
  });

