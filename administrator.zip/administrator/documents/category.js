/**
 * @api {get} /category/lang/:lang get category by language
 * @apiVersion 1.0.0
 * @apiName GetCategoryByLanguage
 * @apiGroup Category
 * @apiPermission none
 *
 * @apiDescription get category by language
 * 
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": [
			{
			   "id": 398,
			   "parent_id": 0,
			   "display_order": 0,
			   "name": "QNAP NAS Server",
			   "children": [
			    {
			       "id": 399,
			       "parent_id": 398,
			       "display_order": 0,
			       "name": "QNAP Standserver",
			        "children": []
			    },
			    {
			       "id": 400,
			       "parent_id": 398,
			       "display_order": 1,
			       "name": "QNAP 19 Zoll Rack-Server",
			       "children": []
			    }]
			}
		]		    
	}
 *
 */

 /**
 * @api {post} /category/ create category
 * @apiVersion 1.0.0
 * @apiName CreateCategory
 * @apiGroup Category
 * @apiPermission none
 *
 * @apiDescription create category
 * 
 * @apiParam {Int} parent_id
 * @apiParam {Int} display_order
 * @apiParam {String} name
 * @apiParam {String} language
 * @apiParam {String} description
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": {
			   "id": 398
			  }
	}
 *
 */


 /**
 * @api {put} /category/:id update category
 * @apiVersion 1.0.0
 * @apiName UpdateCategory
 * @apiGroup Category
 * @apiPermission none
 *
 * @apiDescription update category
 * 
  * @apiParam {Int} category_id
   * @apiParam {Int} id
 * @apiParam {Int} parent_id
 * @apiParam {Int} display_order
 * @apiParam {String} name
 * @apiParam {String} description
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": {
			   "id": 398
			  }
	}
 *
 */

  /**
 * @api {delete} /category/:id delete category
 * @apiVersion 1.0.0
 * @apiName DeleteCategory
 * @apiGroup Category
 * @apiPermission none
 *
 * @apiDescription Delete category
 * 
   * @apiParam {Int} id
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success"
	}
 *
 */

  /**
 * @api {post} /category/:id/lang create category for language
 * @apiVersion 1.0.0
 * @apiName CreateCategoryByLang
 * @apiGroup Category
 * @apiPermission none
 *
 * @apiDescription create category for language
 * 
 * @apiParam {Int} category_id
 * @apiParam {String} name
 * @apiParam {String} language
 * @apiParam {String} description
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": {
			   "id": 398
			  }
	}
 *
 */
