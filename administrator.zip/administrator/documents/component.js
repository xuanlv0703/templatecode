/**
 * @api {get} /component/language/:language get all component by language
 * @apiVersion 1.0.0
 * @apiName GetComponent
 * @apiGroup Component
 * @apiPermission none
 *
 * @apiDescription get list component by language
 * 
 *
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": [
			{
			   "id": 398,
			   "name": 0,
			   "language": 0,
			   "name": "Component name",
			   "display_order": 0
			}
		]		    
	}
 *
 */

 /**
 * @api {post} /component/ create component
 * @apiVersion 1.0.0
 * @apiName CreateComponent
 * @apiGroup Component
 * @apiPermission none
 *
 * @apiDescription create Component
 * 
 *
 * @apiParam {Int} display_order
 * @apiParam {String} name
 * @apiParam {String} language
 *
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": {
			   "id": 398
			  }
	}
 *
 */


 /**
 * @api {put} /component/:id update component
 * @apiVersion 1.0.0
 * @apiName UpdateComponent
 * @apiGroup Component
 * @apiPermission none
 *
 * @apiDescription update Component
 * 
 * @apiParam {Int} component_id
 * @apiParam {Int} id
 * @apiParam {Int} display_order
 * @apiParam {String} name
 *
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": {
			   "id": 398
			  }
	}
 *
 */

  /**
 * @api {delete} /component/:id delete component
 * @apiVersion 1.0.0
 * @apiName DeleteComponent
 * @apiGroup Component
 * @apiPermission none
 *
 * @apiDescription Delete component
 * 
 * @apiParam {Int} id
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success"
	}
 *
 */
