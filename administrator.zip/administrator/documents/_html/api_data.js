define({ "api": [
  {
    "type": "post",
    "url": "/category/",
    "title": "create category",
    "version": "1.0.0",
    "name": "CreateCategory",
    "group": "Category",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>create category</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "parent_id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "display_order",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "language",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": {\n\t\t\t   \"id\": 398\n\t\t\t  }\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/category.js",
    "groupTitle": "Category",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/category/"
      }
    ]
  },
  {
    "type": "post",
    "url": "/category/:id/lang",
    "title": "create category for language",
    "version": "1.0.0",
    "name": "CreateCategoryByLang",
    "group": "Category",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>create category for language</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "category_id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "language",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": {\n\t\t\t   \"id\": 398\n\t\t\t  }\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/category.js",
    "groupTitle": "Category",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/category/:id/lang"
      }
    ]
  },
  {
    "type": "delete",
    "url": "/category/:id",
    "title": "delete category",
    "version": "1.0.0",
    "name": "DeleteCategory",
    "group": "Category",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Delete category</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "id",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\"\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/category.js",
    "groupTitle": "Category",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/category/:id"
      }
    ]
  },
  {
    "type": "get",
    "url": "/category/lang/:lang",
    "title": "get category by language",
    "version": "1.0.0",
    "name": "GetCategoryByLanguage",
    "group": "Category",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>get category by language</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": [\n\t\t\t{\n\t\t\t   \"id\": 398,\n\t\t\t   \"parent_id\": 0,\n\t\t\t   \"display_order\": 0,\n\t\t\t   \"name\": \"QNAP NAS Server\",\n\t\t\t   \"children\": [\n\t\t\t    {\n\t\t\t       \"id\": 399,\n\t\t\t       \"parent_id\": 398,\n\t\t\t       \"display_order\": 0,\n\t\t\t       \"name\": \"QNAP Standserver\",\n\t\t\t        \"children\": []\n\t\t\t    },\n\t\t\t    {\n\t\t\t       \"id\": 400,\n\t\t\t       \"parent_id\": 398,\n\t\t\t       \"display_order\": 1,\n\t\t\t       \"name\": \"QNAP 19 Zoll Rack-Server\",\n\t\t\t       \"children\": []\n\t\t\t    }]\n\t\t\t}\n\t\t]\t\t    \n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/category.js",
    "groupTitle": "Category",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/category/lang/:lang"
      }
    ]
  },
  {
    "type": "put",
    "url": "/category/:id",
    "title": "update category",
    "version": "1.0.0",
    "name": "UpdateCategory",
    "group": "Category",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>update category</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "category_id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "parent_id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "display_order",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": {\n\t\t\t   \"id\": 398\n\t\t\t  }\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/category.js",
    "groupTitle": "Category",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/category/:id"
      }
    ]
  },
  {
    "type": "post",
    "url": "/component/",
    "title": "create component",
    "version": "1.0.0",
    "name": "CreateComponent",
    "group": "Component",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>create Component</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "display_order",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "language",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": {\n\t\t\t   \"id\": 398\n\t\t\t  }\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/component.js",
    "groupTitle": "Component",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/component/"
      }
    ]
  },
  {
    "type": "delete",
    "url": "/component/:id",
    "title": "delete component",
    "version": "1.0.0",
    "name": "DeleteComponent",
    "group": "Component",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Delete component</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "id",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\"\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/component.js",
    "groupTitle": "Component",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/component/:id"
      }
    ]
  },
  {
    "type": "get",
    "url": "/component/language/:language",
    "title": "get all component by language",
    "version": "1.0.0",
    "name": "GetComponent",
    "group": "Component",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>get list component by language</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": [\n\t\t\t{\n\t\t\t   \"id\": 398,\n\t\t\t   \"name\": 0,\n\t\t\t   \"language\": 0,\n\t\t\t   \"name\": \"Component name\",\n\t\t\t   \"display_order\": 0\n\t\t\t}\n\t\t]\t\t    \n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/component.js",
    "groupTitle": "Component",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/component/language/:language"
      }
    ]
  },
  {
    "type": "put",
    "url": "/component/:id",
    "title": "update component",
    "version": "1.0.0",
    "name": "UpdateComponent",
    "group": "Component",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>update Component</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "component_id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "display_order",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": {\n\t\t\t   \"id\": 398\n\t\t\t  }\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/component.js",
    "groupTitle": "Component",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/component/:id"
      }
    ]
  },
  {
    "type": "post",
    "url": "/part/",
    "title": "create part",
    "version": "1.0.0",
    "name": "CreatePart",
    "group": "Part",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>create Part</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "component_id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "display_order",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Float",
            "optional": false,
            "field": "price",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Float",
            "optional": false,
            "field": "vat",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "producer_id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "number",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "tags",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "language",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": {\n\t\t\t   \"id\": 398\n\t\t\t  }\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/part.js",
    "groupTitle": "Part",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/part/"
      }
    ]
  },
  {
    "type": "post",
    "url": "/part/:id/language",
    "title": "create part for language",
    "version": "1.0.0",
    "name": "CreatePartByLang",
    "group": "Part",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>create part for language</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "part_id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "language",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "tags",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": {\n\t\t\t   \"id\": 398\n\t\t\t  }\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/part.js",
    "groupTitle": "Part",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/part/:id/language"
      }
    ]
  },
  {
    "type": "delete",
    "url": "/part/:id",
    "title": "delete part",
    "version": "1.0.0",
    "name": "DeletePart",
    "group": "Part",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Delete part</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "language",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "component_id",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\"\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/part.js",
    "groupTitle": "Part",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/part/:id"
      }
    ]
  },
  {
    "type": "get",
    "url": "/part/language/:language",
    "title": "get all part by language",
    "version": "1.0.0",
    "name": "GetPart",
    "group": "Part",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>get list part by language</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": [\n\t\t\t{\n\t\t\t   \"id\": 398,\n\t\t\t   \"name\": 0,\n\t\t\t   \"language\": 0,\n\t\t\t   \"name\": \"part name\",\n\t\t\t   \"display_order\": 0\n\t\t\t}\n\t\t]\t\t    \n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/part.js",
    "groupTitle": "Part",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/part/language/:language"
      }
    ]
  },
  {
    "type": "put",
    "url": "/part/:id",
    "title": "update part",
    "version": "1.0.0",
    "name": "UpdatePart",
    "group": "Part",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>update part</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "component_id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "id",
            "description": "<p>id in part_i18n table</p>"
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "display_order",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Float",
            "optional": false,
            "field": "price",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Float",
            "optional": false,
            "field": "vat",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "producer_id",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "number",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "tags",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "component_part_id",
            "description": "<p>id in component_part table</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": {\n\t\t\t   \"id\": 398\n\t\t\t  }\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/part.js",
    "groupTitle": "Part",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/part/:id"
      }
    ]
  },
  {
    "type": "post",
    "url": "/tree",
    "title": "create tree",
    "version": "1.0.0",
    "name": "CreateTree",
    "group": "Tree",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>create tree</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": {\n\t\t\t   \"id\": 1\n\t\t\t  }\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/tree.js",
    "groupTitle": "Tree",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/tree"
      }
    ]
  },
  {
    "type": "delete",
    "url": "/tree/:id",
    "title": "delete tree",
    "version": "1.0.0",
    "name": "DeleteTree",
    "group": "Tree",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>Delete tree</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\"\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/tree.js",
    "groupTitle": "Tree",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/tree/:id"
      }
    ]
  },
  {
    "type": "get",
    "url": "/tree/component/:lang",
    "title": "get all component by tree and language",
    "version": "1.0.0",
    "name": "GetComponentTree",
    "group": "Tree",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>get list component by tree and language</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": [\n\t    {\n\t      \"id\": 1,\n\t      \"component_id\": 1,\n\t      \"tree_id\": 1,\n\t      \"display_order\": 1,\n\t      \"parent_id\": 0,\n\t      \"name\": \"component 1\",\n\t      \"children\": [\n\t        {\n\t          \"id\": 2,\n\t          \"component_id\": 2,\n\t          \"tree_id\": 1,\n\t          \"display_order\": 2,\n\t          \"parent_id\": 1,\n\t          \"name\": \"component 2\",\n\t          \"children\": []\n\t        },\n\t        {\n\t          \"id\": 3,\n\t          \"component_id\": 3,\n\t          \"tree_id\": 1,\n\t          \"display_order\": 3,\n\t          \"parent_id\": 1,\n\t          \"name\": \"component 3\",\n\t          \"children\": []\n\t        }\n\t      ]\n\t    },\n\t    {\n\t      \"id\": 4,\n\t      \"component_id\": 4,\n\t      \"tree_id\": 1,\n\t      \"display_order\": 4,\n\t      \"parent_id\": 0,\n\t      \"name\": \"component 4\",\n\t      \"children\": [\n\t        {\n\t          \"id\": 5,\n\t          \"component_id\": 5,\n\t          \"tree_id\": 1,\n\t          \"display_order\": 5,\n\t          \"parent_id\": 4,\n\t          \"name\": \"component 5\",\n\t          \"children\": [\n\t            {\n\t              \"id\": 6,\n\t              \"component_id\": 6,\n\t              \"tree_id\": 1,\n\t              \"display_order\": 6,\n\t              \"parent_id\": 5,\n\t              \"name\": \"component 6\",\n\t              \"children\": []\n\t            }\n\t          ]\n\t        }\n\t      ]\n\t    }\n\t  ]\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/tree.js",
    "groupTitle": "Tree",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/tree/component/:lang"
      }
    ]
  },
  {
    "type": "get",
    "url": "/tree/:id",
    "title": "get tree detail by id",
    "version": "1.0.0",
    "name": "GetTreeDetail",
    "group": "Tree",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>get tree detail by id</p>",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": [\n\t    {\n\t      \"id\": 1,\n\t      \"name\": \"a\",\n\t      \"description\": \"abc\"\n\t    }\n\t  ]\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/tree.js",
    "groupTitle": "Tree",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/tree/:id"
      }
    ]
  },
  {
    "type": "put",
    "url": "/tree/:id",
    "title": "update tree",
    "version": "1.0.0",
    "name": "UpdateTree",
    "group": "Tree",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>update tree</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": ""
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    {\n\t  \"error\": false,\n\t  \"message\": \"Success\",\n\t  \"data\": {\n\t\t\t   \"id\": 1\n\t\t\t  }\n\t}",
          "type": "json"
        }
      ]
    },
    "filename": "documents/tree.js",
    "groupTitle": "Tree",
    "sampleRequest": [
      {
        "url": "http://localhost:9012/api/tree/:id"
      }
    ]
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "documents/_html/main.js",
    "group": "_home_son_Documents_lscomputer_lscomputer_api_administrator_documents__html_main_js",
    "groupTitle": "_home_son_Documents_lscomputer_lscomputer_api_administrator_documents__html_main_js",
    "name": ""
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "documents/template/main.js",
    "group": "_home_son_Documents_lscomputer_lscomputer_api_administrator_documents_template_main_js",
    "groupTitle": "_home_son_Documents_lscomputer_lscomputer_api_administrator_documents_template_main_js",
    "name": ""
  }
] });
