define({
  "name": "LSComputer APIDOC",
  "version": "1.0.0",
  "description": "Documentation from LSComputer API.",
  "title": "Welcome to LSComputer apiDoc",
  "url": "http://localhost:9012/api",
  "sampleUrl": "http://localhost:9012/api",
  "header": {
    "title": "LSComputer Project",
    "content": "<h2><span id=\"api-example-for-a-submenu-entry\">How to use API</span></h2>\n<p>Custom header for each request to server.</p>\n<p>Accept-version: client side send version api for each request to server</p>\n<p>Ex: accept-version: '1.0.0'</p>\n<p>Authentication: client side use their shared key that provided from server to hash access token for each request to server</p>\n<p>Ex: x-access-token: token value</p>\n<p>Response format: Json is default format for all response from server</p>\n<pre><code>{\n  &quot;error&quot;: true/false,\n  &quot;message&quot;: &quot;fail / success&quot;,\n  &quot;data&quot;: [{\n      &quot;username&quot; : &quot;long&quot;,\n      &quot;email&quot; : &quot;longpn@rasia.info&quot;\n    }, {\n      &quot;username&quot; : &quot;hieu&quot;,\n      &quot;email&quot; : &quot;hieu@rasia.info&quot;\n    }]\n}\n</code></pre>\n"
  },
  "footer": {
    "title": "LSComputer",
    "content": "<h1></h1>\n"
  },
  "template": {
    "withCompare": true,
    "withGenerator": true
  },
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-03-28T06:45:44.467Z",
    "url": "http://apidocjs.com",
    "version": "0.17.5"
  }
});
