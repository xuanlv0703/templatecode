/**
 * @api {get} /tree/component/:lang get all component by tree and language
 * @apiVersion 1.0.0
 * @apiName GetComponentTree
 * @apiGroup Tree
 * @apiPermission none
 *
 * @apiDescription get list component by tree and language
 * 
 *
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": [
	    {
	      "id": 1,
	      "component_id": 1,
	      "tree_id": 1,
	      "display_order": 1,
	      "parent_id": 0,
	      "name": "component 1",
	      "children": [
	        {
	          "id": 2,
	          "component_id": 2,
	          "tree_id": 1,
	          "display_order": 2,
	          "parent_id": 1,
	          "name": "component 2",
	          "children": []
	        },
	        {
	          "id": 3,
	          "component_id": 3,
	          "tree_id": 1,
	          "display_order": 3,
	          "parent_id": 1,
	          "name": "component 3",
	          "children": []
	        }
	      ]
	    },
	    {
	      "id": 4,
	      "component_id": 4,
	      "tree_id": 1,
	      "display_order": 4,
	      "parent_id": 0,
	      "name": "component 4",
	      "children": [
	        {
	          "id": 5,
	          "component_id": 5,
	          "tree_id": 1,
	          "display_order": 5,
	          "parent_id": 4,
	          "name": "component 5",
	          "children": [
	            {
	              "id": 6,
	              "component_id": 6,
	              "tree_id": 1,
	              "display_order": 6,
	              "parent_id": 5,
	              "name": "component 6",
	              "children": []
	            }
	          ]
	        }
	      ]
	    }
	  ]
	}
 *
 */

 /**
 * @api {post} /tree create tree
 * @apiVersion 1.0.0
 * @apiName CreateTree
 * @apiGroup Tree
 * @apiPermission none
 *
 * @apiDescription create tree
 * 
 *
 * @apiParam {String} description
 * @apiParam {String} name
 *
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": {
			   "id": 1
			  }
	}
 *
 */


 /**
 * @api {put} /tree/:id update tree
 * @apiVersion 1.0.0
 * @apiName UpdateTree
 * @apiGroup Tree
 * @apiPermission none
 *
 * @apiDescription update tree
 * 
 * @apiParam {String} description
 * @apiParam {String} name 
 *
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": {
			   "id": 1
			  }
	}
 *
 */

  /**
 * @api {delete} /tree/:id delete tree
 * @apiVersion 1.0.0
 * @apiName DeleteTree
 * @apiGroup Tree
 * @apiPermission none
 *
 * @apiDescription Delete tree
 *  
 * 
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success"
	}
 *
 */

 /**
 * @api {get} /tree/:id get tree detail by id
 * @apiVersion 1.0.0
 * @apiName GetTreeDetail
 * @apiGroup Tree
 * @apiPermission none
 *
 * @apiDescription get tree detail by id
 * 
 *
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": [
	    {
	      "id": 1,
	      "name": "a",
	      "description": "abc"
	    }
	  ]
	}
 *
 */
