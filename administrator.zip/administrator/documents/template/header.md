
## <span id="api-example-for-a-submenu-entry">How to use API</span>

Custom header for each request to server.

Accept-version: client side send version api for each request to server

Ex: accept-version: '1.0.0'

Authentication: client side use their shared key that provided from server to hash access token for each request to server

Ex: x-access-token: token value

Response format: Json is default format for all response from server

    {
      "error": true/false,
      "message": "fail / success",
      "data": [{
          "username" : "long",
          "email" : "longpn@rasia.info"
        }, {
          "username" : "hieu",
          "email" : "hieu@rasia.info"
        }]
    }
