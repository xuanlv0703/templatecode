/**
 * @api {get} /part/language/:language get all part by language
 * @apiVersion 1.0.0
 * @apiName GetPart
 * @apiGroup Part
 * @apiPermission none
 *
 * @apiDescription get list part by language
 * 
 *
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": [
			{
			   "id": 398,
			   "name": 0,
			   "language": 0,
			   "name": "part name",
			   "display_order": 0
			}
		]		    
	}
 *
 */

 /**
 * @api {post} /part/ create part
 * @apiVersion 1.0.0
 * @apiName CreatePart
 * @apiGroup Part
 * @apiPermission none
 *
 * @apiDescription create Part
 * 
 *
 * @apiParam {Int} component_id
 * @apiParam {Int} display_order
 * @apiParam {Float} price
 * @apiParam {Float} vat
 * @apiParam {Int} producer_id
 * @apiParam {String} number
 * @apiParam {String} description
 * @apiParam {String} tags
 * @apiParam {String} language
 *
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": {
			   "id": 398
			  }
	}
 *
 */


 /**
 * @api {put} /part/:id update part
 * @apiVersion 1.0.0
 * @apiName UpdatePart
 * @apiGroup Part
 * @apiPermission none
 *
 * @apiDescription update part
 * 
 * @apiParam {Int} component_id
 * @apiParam {Int} id id in part_i18n table
 * @apiParam {Int} display_order
 * @apiParam {Float} price
 * @apiParam {Float} vat
 * @apiParam {Int} producer_id
 * @apiParam {String} number
 * @apiParam {String} description
 * @apiParam {String} tags
 * @apiParam {Int} component_part_id id in component_part table
 *
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": {
			   "id": 398
			  }
	}
 *
 */

  /**
 * @api {delete} /part/:id delete part
 * @apiVersion 1.0.0
 * @apiName DeletePart
 * @apiGroup Part
 * @apiPermission none
 *
 * @apiDescription Delete part
 * 
 * @apiParam {String} language
 * @apiParam {Int} component_id
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success"
	}
 *
 */

 /**
 * @api {post} /part/:id/language create part for language
 * @apiVersion 1.0.0
 * @apiName CreatePartByLang
 * @apiGroup Part
 * @apiPermission none
 *
 * @apiDescription create part for language
 * 
 * @apiParam {Int} part_id
 * @apiParam {String} name
 * @apiParam {String} language
 * @apiParam {String} description
 * @apiParam {String} tags
 * @apiParam {String} language
 *
 * @apiSuccessExample {json} Success-Response:
    {
	  "error": false,
	  "message": "Success",
	  "data": {
			   "id": 398
			  }
	}
 *
 */
