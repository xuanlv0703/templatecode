'use strict';

var mysql = require('mysql');

exports.find = function(connection, done) {
    var query = 'SELECT category.*,category_i18n.name, NULL as children FROM category,category_i18n where category.id = category_i18n.category_id order by parent_id,display_order asc';
    connection.query(query, done);
}

exports.create = function(obj,connection,done){
	connection.getConnection(function(err,cnn){
		cnn.beginTransaction(function(err) {
		  if (err) { done(err); }
		  var objCate = {parent_id:obj.parent_id,display_order:obj.display_order};
		  cnn.query('INSERT INTO category SET ?', objCate, function (error, rs, fields) {
		    if (error) {
		      return cnn.rollback(function() {
		        done(error)
		      });
		    }
		 
			var objCate_I18n={category_id:rs.insertId,name:obj.name,language:obj.language,description:obj.description};
		 
		    cnn.query('INSERT INTO category_i18n SET ?', objCate_I18n, function (error, results, fields) {
		      if (error) {
		        return cnn.rollback(function() {
		           done(error)
		        });
		      }
		      cnn.commit(function(err) {
		        if (err) {
		          return cnn.rollback(function() {
		             done(error)
		          });
		        }
		         done(null,{id:rs.insertId})
		      });
		    });
		  });
		});
	})
}

exports.update = function(obj,connection,done){
	connection.getConnection(function(err,cnn){
		cnn.beginTransaction(function(err) {
		  if (err) { done(err); }
		  var objCate = [{parent_id:obj.parent_id,display_order:obj.display_order},obj.category_id];
		  cnn.query('UPDATE category SET ? where id = ?', objCate, function (error, rs, fields) {
		    if (error) {
		      return cnn.rollback(function() {
		        done(error)
		      });
		    }
		 
			var objCate_I18n=[{name:obj.name,description:obj.description},obj.id];
		    cnn.query('UPDATE category_i18n SET ? where id = ?', objCate_I18n, function (error, results, fields) {
		      if (error) {
		        return cnn.rollback(function() {
		           done(error)
		        });
		      }
		      cnn.commit(function(err) {
		        if (err) {
		          return cnn.rollback(function() {
		             done(error)
		          });
		        }
		         done(null,{id:obj.category_id})
		      });
		    });
		  });
		});
	})
}


exports.delete = function(id,connection,done){
    connection.query('DELETE FROM category_i18n WHERE id = ?', id, function (error, results, fields) {
     	done(error);
    });
}

exports.listbylang = function(lang,connection, done) {
    var query = 'SELECT category.*,category_i18n.name, NULL as children FROM category,category_i18n where category.id = category_i18n.category_id and language=? order by parent_id,display_order asc';
    connection.query(query,lang, done);
}

exports.createbylang = function(obj,connection,done){
	connection.query('select * from category_i18n where category_id=? and language=?',[obj.category_id,obj.language],function(error,rs,fields){
		if(error) done(error);
		if(rs.length==0){
			var objCate_I18n={category_id:obj.category_id,name:obj.name,language:obj.language,description:obj.description};
		    connection.query('INSERT INTO category_i18n SET ?', objCate_I18n, function (error, results, fields) {
		      done(error,{id: results == undefined ? "": results.insertId})
		    });
		}else{
			done('duplicate data');
		}
	})
		
}

