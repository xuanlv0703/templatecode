'use strict';

var mysql = require('mysql');

exports.listbytreeoflang = function(id,lang,connection, done) {
    var query = 'SELECT ct.*,ci.name,NULL as children from component_trees ct,component_i18n ci where ct.component_id=ci.component_id and ct.tree_id=? and ci.language=? order by ct.parent_id,ct.display_order asc';
    connection.query(query,[id,lang], done);
}

exports.listbytreepartoflang = function(id,lang,connection, done) {
    var query = 'SELECT ct.*,ci.name,NULL as children from component_trees ct,component_i18n ci where ct.component_id=ci.component_id and ct.tree_id=? and ci.language=? order by ct.parent_id,ct.display_order asc';
    connection.query(query,[id,lang], done);
}

exports.create = function(tree_id,obj,connection,done){

	connection.getConnection(function(err,cnn){
		cnn.beginTransaction(function(err) {
		  if (err) { done(err); }
		  cnn.query('DELETE FROM component_trees WHERE tree_id= ?', tree_id, function (error, rs, fields) {
		    if (error) {
		    	console.log('delete',error)
		      return cnn.rollback(function() {
		        done(error)
		      });
		    }
		 
		 
		    cnn.query('INSERT INTO component_trees(component_id,tree_id,display_order,parent_id) VALUES ?', [obj], function (error, results, fields) {
		      if (error) {
		      	console.log('INSERT',error)
		        return cnn.rollback(function() {
		           done(error)
		        });
		      }
		      cnn.commit(function(err) {
		        if (err) {
		        	console.log('commit',err)
		          return cnn.rollback(function() {
		             done(error)
		          });
		        }
		         done(null,true)
		      });
		    });
		  });
		});
	})
}

exports.find = function(connection, done) {
    var query = 'SELECT * FROM trees'; 	    
    connection.query(query, done);
}

exports.findById = function(id, connection, done) {
    var query = 'SELECT * FROM trees WHERE id = ?'; 	    
    connection.query(query, id, done);
}

exports.create = function(obj,connection,done){
	var objTree = {name: obj.name, description: obj.description};
	connection.query('INSERT INTO trees SET ?', objTree, done);
}

exports.update = function(obj, id, connection,done){
	var objTree = {name: obj.name, description: obj.description};
	connection.query('UPDATE trees SET ? where id = ?', [objTree, id], done);	
}

exports.delete = function(id, connection,done){		
	connection.query('DELETE FROM trees where id = ?', id, done);
}
