'use strict';

var mysql = require('mysql');

exports.findByLang = function(lang, connection, done) {
    var query = 'SELECT component.*,component_i18n.name\
                 FROM component,component_i18n\
                 WHERE language = ? AND component.id = component_i18n.component_id order by display_order asc'; 	    
    connection.query(query, lange, done);
}

exports.create = function(obj,connection,done){
	connection.getConnection(function(err,cnn){
		cnn.beginTransaction(function(err) {
		  if (err) { done(err); }
		  var objComponent = {display_order:obj.display_order};
		  cnn.query('INSERT INTO component SET ?', objComponent, function (error, rs, fields) {
		    if (error) {
		      return cnn.rollback(function() {
		        done(error)
		      });
		    }
		 
			var objComponent_I18n={component_id:rs.insertId,name:obj.name,language:obj.language};
		 
		    cnn.query('INSERT INTO component_i18n SET ?', objComponent_I18n, function (error, results, fields) {
		      if (error) {
		        return cnn.rollback(function() {
		           done(error)
		        });
		      }
		      cnn.commit(function(err) {
		        if (err) {
		          return cnn.rollback(function() {
		             done(error)
		          });
		        }
		         done(null,{id:rs.insertId})
		      });
		    });
		  });
		});
	})
}


exports.update = function(obj,connection,done){
	connection.getConnection(function(err,cnn){
		cnn.beginTransaction(function(err) {
		  if (err) { done(err); }
		  var objComponent = [{display_order:obj.display_order},obj.component_id];
		  cnn.query('UPDATE component SET ? where id = ?', objComponent, function (error, rs, fields) {
		    if (error) {
		      return cnn.rollback(function() {
		        done(error)
		      });
		    }
		 
			var objComponent_I18n=[{name:obj.name},obj.id];
		    cnn.query('UPDATE component_i18n SET ? where id = ?', objComponent_I18n, function (error, results, fields) {
		      if (error) {
		        return cnn.rollback(function() {
		           done(error)
		        });
		      }
		      cnn.commit(function(err) {
		        if (err) {
		          return cnn.rollback(function() {
		             done(error)
		          });
		        }
		         done(null,{id:obj.component_id})
		      });
		    });
		  });
		});
	})
}


exports.delete = function(id,connection,done){
    connection.query('DELETE FROM component_i18n WHERE id = ?', id, function (error, results, fields) {
     	done(error);
    });
}

exports.createbylang = function(obj,connection,done){
	connection.query('select * from component_i18n where component_id=? and language=?',[obj.component_id,obj.language],function(error,rs,fields){
		if(error) done(error);
		if(rs.length==0){
			var objComponet_I18n={component_id:obj.component_id,name:obj.name,language:obj.language};
		    connection.query('INSERT INTO category_i18n SET ?', objComponet_I18n, function (error, results, fields) {
		    done(error,{id: results == undefined ? "": results.insertId})
		    });
		}else{
			done('duplicate data');
		}
	})
		
}
