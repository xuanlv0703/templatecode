'use strict';

var mysql = require('mysql');

exports.findByLang = function(lang, connection, done) {
    var query = 'SELECT part.*,part_i18n.*\
                 FROM part,part_i18n\
                 WHERE language = ? AND part.id = part_i18n.part_id'; 	    
    connection.query(query, lang, done);
}

exports.getpartbycomponentbylang = function(component_id,lang, connection, done) {
    var query = 'select * from component_part cp,part p ,part_i18n pi where cp.part_id = p.id and p.id = pi.part_id and cp.component_id=? and pi.language=?'; 	    
    connection.query(query, [component_id,lang], done);
}

exports.create = function(obj,connection,done){
	connection.getConnection(function(err,cnn){
		cnn.beginTransaction(function(err) {
		  if (err) { done(err); }
		  var objpart = {number: obj.number, price: obj.price, producer_id: obj.producer_id, vat: obj.vat};
		  cnn.query('INSERT INTO part SET ?', objpart, function (error, rs, fields) {
		    if (error) {
		      return cnn.rollback(function() {
		        done(error)
		      });
		    }
		 
			var objpart_I18n={part_id:rs.insertId,name:obj.name,language:obj.language, description: obj.description, tags: obj.tags};
		 
		    cnn.query('INSERT INTO part_i18n SET ?', objpart_I18n, function (error, results, fields) {
			      if (error) {			      	
			        return cnn.rollback(function() {
			           done(error)
			        });
			      }

		    	var objpart_component={display_order:obj.display_order,part_id:rs.insertId, component_id: obj.component_id, display_order: obj.display_order};
		 
			    cnn.query('INSERT INTO component_part SET ?', objpart_component, function (error, results2, fields) {
				      if (error) {
				        return cnn.rollback(function() {
				           done(error)
				        });
				      }

				      cnn.commit(function(err) {
				        if (err) {
				          return cnn.rollback(function() {
				             done(error)
				          });
				        }
				         done(null,{id:rs.insertId})
				      });
			    });
		  	});
			});
		});
});
}

exports.update = function(obj,connection,done){
	connection.getConnection(function(err,cnn){
		cnn.beginTransaction(function(err) {
		  if (err) { done(err); }
		  var objpart = [{number: obj.number, price: obj.price, producer_id: obj.producer_id, vat: obj.vat},obj.part_id];

		  cnn.query('UPDATE part SET ? where id = ?', objpart, function (error, rs, fields) {
		    if (error) {
		      return cnn.rollback(function() {
		        done(error)
		      });
		    }
		 
			var objpart_I18n=[{name:obj.name, description: obj.description, tags: obj.tags},obj.id];
		    cnn.query('UPDATE part_i18n SET ? where id = ?', objpart_I18n, function (error, results, fields) {
		      if (error) {
		        return cnn.rollback(function() {
		           done(error)
		        });
		      }

		    var objpart_component=[{display_order:obj.display_order, component_id: obj.component_id},obj.component_part_id];
		    cnn.query('UPDATE component_part SET ? where id = ?', objpart_component, function (error, results, fields) {
		    if (error) {
		        return cnn.rollback(function() {
		           done(error)
		        });
		      }
		  	});

		      cnn.commit(function(err) {
		        if (err) {
		          return cnn.rollback(function() {
		             done(error)
		          });
		        }
		         done(null,{id:obj.part_id})
		      });
		    });
		  });
		});
	})
}


exports.delete = function(id, language, component_id, connection,done){	
	connection.getConnection(function(err,cnn){
		cnn.beginTransaction(function(err) {
		  if (err) { done(err); }
		  cnn.query('DELETE FROM part_i18n WHERE part_id = ? AND language = ?', [id, language], function (error, results, fields) {
		    if (error) {		    
		      return cnn.rollback(function() {
		        done(error)
		      });
		    }
		 
			cnn.query('DELETE FROM component_part WHERE part_id = ? AND component_id = ?', [id, component_id], function (error, results, fields) {
		      if (error) {		      
		        return cnn.rollback(function() {
		           done(error)
		        });
		      }
		      cnn.commit(function(err) {
		        if (err) {
		          return cnn.rollback(function() {
		             done(error)
		          });
		        }
		         done(null,{id:id})
		      });
		    });
		  });
		});
	})    
}

exports.createbylang = function(obj,connection,done){
	connection.query('select * from part_i18n where part_id=? and language=?',[obj.part_id,obj.language],function(error,rs,fields){
		if(error) {			
			done(error);
		}
		if(rs.length==0){
			var objPart_I18n={name:obj.name, description: obj.description, tags: obj.tags, language:obj.language, part_id: obj.part_id};
		    connection.query('INSERT INTO part_i18n SET ?', objPart_I18n, function (error, results, fields) {
		    done(error,{id: results == undefined ? "": results.insertId})
		    });
		}else{
			done('duplicate data');
		}
	})
		
}