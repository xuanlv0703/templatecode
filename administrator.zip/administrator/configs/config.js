module.exports = {
    'secret': 'rasia-team',
    'localhost': '0.0.0.0',
    'api_port': 9002,
    'db_conn': {
        'development': {
            connectionLimit: 100,
            host: '172.16.0.68',
            user: 'dev',
            password: 'dev123',
            database: 'lscomputer',
            debug: false
        }
    },
    'version': {
        v1: '1.0.0',
        v2: '2.0.0',
        v3: '3.0.0'
    }
};
