#!/bin/bash

cd /usr/src/app
if [ ! -d "people_iot" ]; then
    mkdir people_iot
fi
cd people_iot

if [ ! -f "server.js" ]; then
    git clone http://docker:12345678@gitlab.rasia.wiki/rutledge/people_device_iot.git .
    git checkout master
	git submodule init
	git submodule update
	cp /tmp/app.module.js  /usr/src/app/people_iot/app/app.module.js 
	cp /tmp/server.js  /usr/src/app/people_iot/server.js
fi

npm install
node server.js
