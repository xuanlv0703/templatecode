----- People IOT docker (NodeJS) -----

--- How to run it ? ---
docker run -d --net rutledge --ip 172.20.0.70 -p 9010:8080 --name rutledge_people_iot rasia_rutledge/people_iot