#create ip network
docker network create --subnet=172.40.0.0/16 rutledge3

#run mysql
docker run -d --net rutledge3 --ip 172.40.0.68 -e MYSQL_PASS="rasia@123" --name rutledge_mysql3 rasia_rutledge/mysql

#run api-people iot
docker run -d --net rutledge3 --ip 172.40.0.69 --name rutledge_people_api3 rasia_rutledge/people_iot_api
docker cp config3/people-iot-api/config.js rutledge_people_api3:/tmp
#docker restart rutledge_people_api3

#run activeMQ
docker run -d --net rutledge3 --ip 172.40.0.71 --name activemq3 rasia_rutledge/activemq

#run distance position
docker run -d --net rutledge3 --ip 172.40.0.72 --name rutledge_distance_position3 rasia_rutledge/distance_position
docker cp config3/distance-postion/zero.json rutledge_distance_position3:/tmp
#docker restart rutledge_distance_position2
#run people iot app
docker run -d --net rutledge3 --ip 172.40.0.70 --name rutledge_people_iot3 rasia_rutledge/people_iot
docker cp config3/people-iot/app.module.js rutledge_people_iot3:/tmp
docker cp config3/people-iot/server.js rutledge_people_iot3:/tmp
#docker restart rutledge_people_iot3