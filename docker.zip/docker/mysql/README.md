----- MySQL docker-----

--- How to run it ? ---
docker run -d --net rutledge --ip 172.20.0.68 -p 3307:3306 -e MYSQL_PASS="rasia@123" --name rutledge_mysql rasia_rutledge/mysql