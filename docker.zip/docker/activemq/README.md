----- AcitveMQ docker -----

--- How to run it ? ---
docker run -d --net rutledge --ip 172.20.0.71 -p 61616:61616 -p 8161:8161 --name activemq rasia_rutledge/activemq