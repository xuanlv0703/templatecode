#create ip network
docker network create --subnet=172.50.0.0/16 rutledge4

#run mysql
docker run -d --net rutledge4 --ip 172.50.0.68 -e MYSQL_PASS="rasia@123" --name rutledge_mysql4 rasia_rutledge/mysql

#run api-people iot
docker run -d --net rutledge4 --ip 172.50.0.69 --name rutledge_people_api4 rasia_rutledge/people_iot_api
docker cp config4/people-iot-api/config.js rutledge_people_api4:/tmp
#docker restart rutledge_people_api4

#run activeMQ
docker run -d --net rutledge4 --ip 172.50.0.71 --name activemq4 rasia_rutledge/activemq

#run distance position
docker run -d --net rutledge4 --ip 172.50.0.72 --name rutledge_distance_position4 rasia_rutledge/distance_position
docker cp config4/distance-postion/zero.json rutledge_distance_position4:/tmp
#docker restart rutledge_distance_position4
#run people iot app
docker run -d --net rutledge4 --ip 172.50.0.70 --name rutledge_people_iot4 rasia_rutledge/people_iot
docker cp config4/people-iot/app.module.js rutledge_people_iot4:/tmp
docker cp config4/people-iot/server.js rutledge_people_iot4:/tmp
#docker restart rutledge_people_iot4