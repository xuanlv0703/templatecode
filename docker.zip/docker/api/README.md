----- API docker (NodeJS) -----

--- How to run it ? ---
docker run -d --net rutledge --ip 172.20.0.69 -p 9009:8080 --name rutledge_people_api rasia_rutledge/people_iot_api