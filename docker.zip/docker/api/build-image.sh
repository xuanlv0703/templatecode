#!/bin/bash

docker build -t rasia_rutledge/people_iot_api:latest .
