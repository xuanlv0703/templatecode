#!/bin/bash
cd /usr/src/app
if [ ! -d "people_api" ]; then
	mkdir people_api
fi
cd people_api

if [ ! -f "server.js" ]; then
	git clone http://docker:12345678@gitlab.rasia.wiki/rutledge/api_people_device_iot.git .
	git checkout master
	git submodule init
	git submodule update
	cp /tmp/config.js /usr/src/app/people_api/config.js
fi

npm install
node server.js