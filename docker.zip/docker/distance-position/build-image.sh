#!/bin/bash

docker build -t rasia_rutledge/distance_position:latest .