----- Distance to position docker (NodeJS) -----

--- How to run it ? ---
docker run -d --net rutledge --ip 172.20.0.72 -p 9000:8080 -p 15747:15747 --name rutledge_distance_position rasia_rutledge/distance_position