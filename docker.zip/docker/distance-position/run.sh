#!/bin/bash
cd /usr/src/app
if [ ! -d "distance_position" ]; then
	mkdir distance_position
fi
cd distance_position

if [ ! -f "index.js" ]; then
	git clone http://docker:12345678@gitlab.rasia.wiki/rutledge/distance_position.git .
	git checkout master
	git submodule init
	git submodule update
	cp /tmp/zero.json /usr/src/app/distance_position/page/zero.json
fi
npm install
node index.js