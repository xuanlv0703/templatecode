#create ip network
docker network create --subnet=172.20.0.0/16 rutledge1

#run mysql
docker run -d --net rutledge1 --ip 172.20.0.68  -e MYSQL_PASS="rasia@123" --name rutledge_mysql1 rasia_rutledge/mysql

#run api-people iot
docker run -d --net rutledge1 --ip 172.20.0.69  --name rutledge_people_api1 rasia_rutledge/people_iot_api
docker cp config1/people-iot-api/config.js rutledge_people_api1:/tmp
#docker restart rutledge_people_api1

#run activeMQ
docker run -d --net rutledge1 --ip 172.20.0.71 --name activemq1 rasia_rutledge/activemq

#run distance position
docker run -d --net rutledge1 --ip 172.20.0.72 --name rutledge_distance_position1 rasia_rutledge/distance_position
docker cp config1/distance-postion/zero.json rutledge_distance_position1:/tmp
#docker restart rutledge_distance_position1
#run people iot app
docker run -d --net rutledge1 --ip 172.20.0.70 --name rutledge_people_iot1 rasia_rutledge/people_iot
docker cp config1/people-iot/app.module.js rutledge_people_iot1:/tmp
docker cp config1/people-iot/server.js rutledge_people_iot1:/tmp
#docker restart rutledge_people_iot1