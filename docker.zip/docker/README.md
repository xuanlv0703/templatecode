--- Create List IP ---
docker network create --subnet=172.20.0.0/16 rutledge


------How to run docker-run*.sh-------------
Before to run file please build all images.

-------How to init distance position----------
"wheelr": "init" : init collection data
"wheelr": "env"  : get environment parameter
"wheelr": "start": begin run

After change page/zero.json config file we need to copy into running container, and restart it

Need to update device ID and position on database according to real device information.