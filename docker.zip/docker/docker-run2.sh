#create ip network
docker network create --subnet=172.30.0.0/16 rutledge2

#run mysql
docker run -d --net rutledge2 --ip 172.30.0.68 -e MYSQL_PASS="rasia@123" --name rutledge_mysql2 rasia_rutledge/mysql

#run api-people iot
docker run -d --net rutledge2 --ip 172.30.0.69 --name rutledge_people_api2 rasia_rutledge/people_iot_api
docker cp config2/people-iot-api/config.js rutledge_people_api2:/tmp
#docker restart rutledge_people_api2

#run activeMQ
docker run -d --net rutledge2 --ip 172.30.0.71 --name activemq2 rasia_rutledge/activemq

#run distance position
docker run -d --net rutledge2 --ip 172.30.0.72 --name rutledge_distance_position2 rasia_rutledge/distance_position
docker cp config2/distance-postion/zero.json rutledge_distance_position2:/tmp
#docker restart rutledge_distance_position2
#run people iot app
docker run -d --net rutledge2 --ip 172.30.0.70 --name rutledge_people_iot2 rasia_rutledge/people_iot
docker cp config2/people-iot/app.module.js rutledge_people_iot2:/tmp
docker cp config2/people-iot/server.js rutledge_people_iot2:/tmp
#docker restart rutledge_people_iot2