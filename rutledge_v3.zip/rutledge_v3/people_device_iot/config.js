module.exports = {
	'secret': 'rutledge_team',
	'localhost':'127.0.0.1',
	'port':9010,
};