var net = require('net');
var mqtt = require('mqtt');
var express = require("express");
var app = express();
var http = require('http').Server(app);
var bodyParser = require("body-parser");
var mysql = require("mysql");
var config = require('./config');

// var Data = require('./open-rssi');
var Data = require('./indoor-rssi');
var KalmanFilter = require('kalmanjs').default;

var noise = { R: 0.01, Q: 10 };
var kalman = new KalmanFilter(noise);

Array.prototype.max = function() {
  return Math.ceil(Math.max.apply(null, this));
};

Array.prototype.min = function() {
  return Math.ceil(Math.min.apply(null, this));
};



var server = mqtt.connect(config.brokerPort, {
    username: config.username,
    password: config.password
});




function avg(arr){
	var total=0;
	for(var i =0 ; i<arr.length;i++){
		total+=arr[i];
	}
	return Math.ceil(total/(arr.length));
}



var raw = [], sample = [], distance_max_min = [];

for (var mk in Data) {
  var vals = Data[mk].map(function(e) {
    return kalman.filter(e);
  })

  raw.push({name: mk, data: Data[mk]});
  sample.push({name: mk, data: vals});
  console.log("distance:" + mk);
  console.log("max value : "+ vals.max());
  console.log("min value : "+ vals.min());
  console.log("-----------------------");
  distance_max_min.push({distance:mk,max: vals.max(),min:vals.min()});
}


// var test = [-48, -51, -49, -51, -53];
// var kalman1 = new KalmanFilter(noise);
//  var abc = test.map(function(e) {
//     return kalman1.filter(e);
//   })
//  console.log(abc);

// console.log(avg(test));


function between(x, min, max) {
  return x >= min && x <= max;
}

function minmax(x,min,max){
	if(x > min) return 1;
	if(x < max) return 89;
}

var distanceByRSSI = function(rssi){
	for(var j=0; j<distance_max_min.length;j++){
		if(between(rssi,distance_max_min[j].min,distance_max_min[j].max)){
			return distance_max_min[j].distance.slice(0,-1);
		}
	}
	return minmax(rssi,-87,-48);
}


var rssi_cache = [], rssi_cache1=[], countTest=0;



var client = net.connect({host:'172.16.0.116', port:4901}, function() {
  // 'connect' listener
  console.log('connected to server!');
});

client.on('end', function() {
  console.log('disconnected from server');
});

function Rest_Server() {
	this.connectMysql();
}


var ListData = [];
var list_static_node = ['C42078431D5FAD57','924ED509B0F1B393','CCC35330626B9785'];
var list_mobile_node = ['33EAF4C936A88FB3'];

for(var i=0;i<list_static_node.length;i++){
	for(var j=0;j<list_mobile_node.length;j++){
		ListData.push({static:list_static_node[i],mobile:list_mobile_node[j],rssi:[]});
	}
	
}

console.log(ListData);
// Create a connection to database
Rest_Server.prototype.connectMysql = function() {
	var self = this;
	var pool = mysql.createPool({
		connectionLimit : 100,
		host : '172.16.0.69',
		port :'3306',
		user : 'root',
		password : 'root',
		database : 'testRSSI',
		debug : false
	});
	pool.getConnection(function(err, connection) {
		if (err) {
			self.stop(err);
		} else {
			self.configureExpress(connection);
			client.on('data', function(data) {
			var dataString = data.toString().split(" ");
			var rssi = dataString[0];
			var longid = dataString[1];
			var longsid =dataString[2].trim();
			if(isNaN(rssi) || list_mobile_node.indexOf(longid) == -1){
				return;
			}

			//push rssi to listData
			for(var i=0;i<ListData.length;i++){
				if(ListData[i].static == longsid && ListData[i].mobile == longid){
					ListData[i].rssi.push(parseInt(rssi));
					console.log("count: "+ListData[i].rssi.length +" rssi: "+rssi+ " from "+longsid+ " to "+longid);

					if(ListData[i].rssi.length >2){
					  var kalman1 = new KalmanFilter(noise);
					  var rssifilter = ListData[i].rssi.map(function(e) {
					    return kalman1.filter(e);
					  });
					  ListData[i].rssi = [];
					  console.log(rssifilter);
					  //console.log("rssi:"+avg(rssifilter)+" and distance from static "+ListData[i].static+" to mobile "+ListData[i].mobile+  " after kalman filter:" + distanceByRSSI(avg(rssifilter))+"m");

					  var sData = {longid: ListData[i].mobile, longsid: ListData[i].static, rssi: avg(rssifilter), distance: distanceByRSSI(avg(rssifilter))};
					  console.log(sData);
					  server.publish('distances', JSON.stringify(sData));
					  // var test = {longid: '33EAF4C936A88FB3', longsid: 'STAC0073', distance: 8};
					  // server.publish('distances',JSON.stringify(test));
					}
					break;
				}
			}
			// countTest++;
			// var query = "INSERT INTO ??(??,??,??,??) VALUES (?,?,?,?)";
			// var launchDate = new Date();
			// var table = [ "statistic", "rssi", "longid", "longsid", "time", rssi, longid, longsid, launchDate];
			// query = mysql.format(query, table);
			// connection.query(query);

			// if(countTest==15){
			// 	countTest=0;
			// 	console.log("timeend: " + launchDate);
			// }
			});
		}
	});
};


// Configuration Express and do start server
Rest_Server.prototype.configureExpress = function(connection) {
	var self = this;
	app.use(bodyParser.urlencoded({
		extended : true
	}));
	app.use(bodyParser.json());
	var router = express.Router();
	app.use('/', router);
	self.startServer();
};
// Start server at port 3000
Rest_Server.prototype.startServer = function() {
	http.listen(3000, function() {
		console.log("All right ! I am alive at Port 3000.");
	});
};
// Stop server
Rest_Server.prototype.stop = function(err) {
	console.log("ISSUE WITH MYSQL n" + err);
	process.exit(1);
};

new Rest_Server(); 
