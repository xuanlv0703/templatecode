var page4 = require('../../page/four')
var itis = require('../../core/itis')

var j4f = function () { console.log('J$F!') }
var deployed = page4.simulation.deployments
var playtags = page4.simulation.tagsinplay

var serials = page4.custom.serials
exports.relays = Object.keys(serials).
  map(function (_no) {
    if (serials[_no][1] != 'relay') return
    return serials[_no][0] 
  }).
  filter(function (brd) { return !itis.Empty(brd) })

exports.connect = function (dbinf, func) {
  if (!itis.Function(func)) func = j4f
  j4f(), func() // simple enough here
}

exports.close = function (func) {
  process.stdout.write('DB closing...... NAH!!!' + j4f())
}

exports.static = function (relayid, handler) {
  handler(null, [{ 
    "deviceid": relayid, 
    "coordinates": deployed[relayid].toString()
  }])
}

exports.device_name = function (tagid, handler) {
  handler(null, playtags.filter(
    function (tag) { return tag.id == tagid })) 
}