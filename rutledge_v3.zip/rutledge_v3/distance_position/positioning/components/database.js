var MySQL = require('mysql')
var pool = null

exports.connect = function (dbinf, done) {
  if (typeof done != 'function') done = function (err) { err && console.log(err) }
  if (!(dbinf instanceof Object)) done(new Error('Unknown information'))
  
  pool = MySQL.createPool(dbinf)
  
  pool.getConnection(function (conn_err, conn) {
    if (conn_err) done(conn_err)
    else {
      conn.query('SELECT @@version', function (err, rows) {
        if (!err) {
          var dbsvr = rows[0]['@@version']
          conn.release(), 
          process.stdout.write("Database version= "+dbsvr),
          process.stdout.write(" /address= "+dbinf.host+':'+dbinf.port+'\n')
        } 
        done(err)
      })
    }
  })

  pool.on('connection', function (conn) {
    var timestamp = new Date().toLocaleString()
    process.stdout.write('(( '+timestamp+' )) '),
    process.stdout.write('DB-connection on thread= '+conn.threadId+'\n')
  })

  return pool
}

exports.close = function (func) {
  if (pool) pool.end(func)
}

exports.static_list = function (func) {
  var stmt = 'SELECT ??, ?? FROM ?? WHERE ?? = ?'
  var vals = ['deviceid', 'coordinates', 'device_deployment', 'type', 'relay']

  stmt = MySQL.format(stmt, vals)
  if (pool) pool.query(stmt, function (err, results) {
    if(err) console.log('!!! Query ERROR !!!', err.message), process.exit(1)
    
    console.log('query results='), console.log(results)
    if (typeof func == 'function') func(results)
  })
}

exports.static = function (stcID, func) {
  var stmt = 'SELECT coordinates FROM ?? WHERE ?? = ? AND ?? = ?'
  var vals = ['device_deployment', 'deviceid', stcID, 'type', 'relay']

  stmt = MySQL.format(stmt, vals)
  if (pool) pool.query(stmt, func)
}

exports.device_name = function (dvc_id, func) {
  var stmt = 'SELECT `name` FROM `device` WHERE ?? = ?'
  var vals = ['id', dvc_id]

  stmt = MySQL.format(stmt, vals)
  if (pool) pool.query(stmt, func)
}