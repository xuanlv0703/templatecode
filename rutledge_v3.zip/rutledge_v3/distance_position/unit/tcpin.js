// require('./mechina'); // hope it works well!
// var page0 = require('./page.zero')
// var page0 = load.page('zero')
// var netcp = require('./libs/link.netcp')
// var broki = require('./libs/link.broker')
// var broki = load.link('broker')
// var axise = require('./libs/core.axis')
// var axise = load.core('axis')
// var timee = require('./libs/core.clock')()
// var timee = load.core('clock')()
require('../mechina'); // yes, it does really good!
var netcp = load.link('netcp')
var timee = clock().stopwatch()
; // end of requiring necessary scipts

var routes = page0.channel // forwarding channels, or other purposes
var mighty = page0.border // board config-ed information
var client = geckoserver(mighty, messaging) // just to get the `write`-dull
var linkee = broker(state).connect() // creation of outspace connection
var memory = { stack:[], heap:{} } // memory in run
var stream = {
  // for any rough data handler out there,
  rocky: linkee.forward(routes.roughdata),
  // and one for the data has its own meanings
  parse: linkee.forward(routes.borderbasket)
} 
; // end of runtime variables

// configure interface connected to mighty gecko boards
function geckoserver (opts, handler) {
  var _ip = +process.env.BORDER_IP || '125' // the only needed param for now 
  if (isNaN(_ip)) throw new Error("No board chosen!")
  opts.host += _ip // there's necessary part already
  return netcp(opts, handler) // connect it!
}

// filter what's really needed
function abandon (data) {
  var piece = data[0] || data 
  var abort = false // final result in here
  var tests = [ 
    isNaN(+piece), // the first's always a number
    // (+piece || 0) < 0, // musta be a negative
    itis.Empty(piece) // is it sometime?
  ].map(function (elt) { 
    return abort = abort || elt
  }) // will it be more complex?

  return abort // just fill the empty spaces :)))
}

// `messaging` is a proper name for data handler ?! 
function handler (data) {
  // initial manipulate data from board
  data = data.toString().trim()
  data.split(/\s?(\r|\\r)(\n|\\n)/).map(messaging)
}

function messaging (data) {
  timee.click() // stop the time at each retrieval
  // data = data.replace(/\s?\r\n$/, '')

  // first parsing of data 
  memory.heap = { // dynamic data memory
    raw: data.trim(), // raw data string retrieved
    time: timee.now.toString(), // time of this retrieval
    interval: timee.diff // interval from previous one
  }, stream.rocky.data(memory.heap) // maybe this just for audittin'

  // temporary memory for splitted data
  memory.stack = data.split(' ') // static memory
  // log data at this interface
  // timee.facet(true, true) // do i need to see current date? 
  //  console.log(data.toString().trim()) // this is the most rocky data
  console.log(
    timee.shortstamp(), 
    timee.diff, 
    data.toString().trim())
  
  if (abandon(memory.stack)) return
  
  // assign meanings to splitted data

  memory.heap.rssi = +memory.stack[0]
  memory.heap.lqi = +memory.stack[3]

  memory.heap.target = memory.stack[1]
  // memory.heap.longid = memory.stack[1]
  memory.heap.scanner = memory.stack[2]
  // memory.heap.longsid = memory.stack[2]

  // end assigning
  
  // forward it to who's interested in
  stream.parse.message(memory.heap)
  console.log('parsed:', memory.heap, '\n')
}