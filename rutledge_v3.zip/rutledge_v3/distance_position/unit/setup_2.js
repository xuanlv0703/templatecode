require('../mechina');

var runenv = page0.variation // running variables
var filter = load.calc('kfilter').filter
var logpth = load.calc('logpath').logpath

var fs = require('fs')
var page = directory(__dirname, '..', 'page')
var filen = page('params.json')
var xcludes = [] // keep track of server/excluded boards
var special = '' // when no. of special boards got increased?!
var memomap = paramload()

// create & assign loaded values
if (Object.keys(memomap).length) {
  print('LOADED!\n')
  eachprop(memomap, function (dvid, model) {
    print('*** Loading values for', dvid, '\n')

    delete model.logpth.watch // no need this data
    memomap[dvid] = createmodel() // 
    copy(model.logpth, memomap[dvid].logpth)

    eachprop(model.filter, function (dvc, data) {
      memomap[dvid].filter[dvc] = new filter(runenv)
      copy(data, memomap[dvid].filter[dvc])
    })
  })
}

load.link('dbconn')('development').
  connect().query({
    sql: 'select ??, ??, ?? from `device_deployment`',
    values: ['deviceid', 'coordinates', 'type']
  }, 
  function (devices) {
    print('&&& Founding d-map for', devices.length, 'devices!\n')
    // console.log(devices)
    
    // get (the) special one(s) first!
    special = devices.filter(function (dv) { 
      return streql(dv.type, 'special') })[0] // the special one!
    if (!special) throw new Error("No special device. Stopped!")

    delete special.coordinates // unnecessary data
    console.log('&&& Special device', special)

    setup(devices) // time for real set up
    listening() // when everything is ready!    
  });

process.on('exit', 
  function (code) {
    print('Exiting with code', code, '\n')
  })

/** from this point, data handlers are defined */

// set up in-memory distance map b/w relays
function setup (devices) {
  devices.map(function (dv) {
    var dvid = dv.deviceid

    switch (lower(dv.type)) {
      case 'server': xcludes.push(dvid); break
      // case 'mobile': break
      case 'relay': 
        if (itis.Empty(memomap[dvid])) {
          print('&&& New creation for', dvid, '! ')
          // create models for according relay
          memomap[dvid] = createmodel()

          var coord = numsplit(dv.coordinates)
          var map = getmap(dvid, coord)

          // things need to be kept an eye on
          memomap[dvid].logpth.polen = map[0]
          memomap[dvid].logpth.terra = { 
            source: special.deviceid, 
            d: 1.1 + rand() 
          }
        } 

        break
    }
  })

  // calculate distance from the specified relay to other relays
  function getmap (dvid, coord) {
    return backloop(devices, function (dv) {
      // check & ignore no-interested devices
      if (!streql(dv.type, 'relay') || 
        streql(dv.deviceid, dvid)) return
      
      // get neccessary point coordinates, & calculate the d
      var _c = numsplit(dv.coordinates)
      var _d = distance(coord, _c) + rand()
      
      return { source:dv.deviceid, d:_d }

    }).filter(function (dv) { 
      return !itis.Undefined(dv) 
    }).sort(function (bef, aft) {
      // return bef.d - aft.d // ascending
      return aft.d - bef.d // descending
    }) 
  }
}

// start listening to parsed data
function listening () {
  var linkee = broker(state).connect()  
  var result = linkee.sendto(page0.channel.calibre)

  linkee.on(page0.channel.borderbasket).do(
    function (data) {
      var address = memomap[data.scanner]
      if (!address) return // wonder if it could be the case

      if (xcludes.has(data.target)) return // no need of server
      if (streql(special, data.target)) undefined; // need to do smth here?
      
      if (!address.filter[data.target]) 
        address.filter[data.target] = new filter(runenv);

      var kf = address.filter[data.target]
      var value = kf.value(data.rssi)
      if (!runenv.filter) value = data.rssi 
      
      print(
        clock.shortstamp(new Date(data.time)),
        data.rssi, value, data.scanner, data.target, ''
      )

      address.logpth.calibrate(value, data.target)
      data.distance = address.logpth.distance(value)

      if (!isNaN(+data.distance)) { 
        print(data.distance)
        result.letter(data) 
      }
      
      print('\n'), jsonfy(memomap)
    }
  )
}

/** mini functional parts */

function distance (n1, n2) {
  return Math.sqrt(dsqr(0) + dsqr(1))
  function dsqr (i) {
    return Math.pow((n2[i] - n1[i]) || 0, 2)
  }
}

function rand () { return Math.random()*0.11 }

function paramload () {
  try { 
    print('*** Finding old params... ')
    return require(filen)
  } catch (e) {
    // console.log('actual error:', e)
    print('Nothing loaded!\n')
    return {} 
  }
}

function jsonfy (obj) {
  // print('saving... ')
  fs.writeFile(filen, 
    JSON.stringify(obj),
    function (err) {
      if (err) throw err
      // print('Params saved!\n')
    })
}

function timesave () {
  var param = page.bind(null, 'param')
  var time = clock.shortstamp()
  
  time = time.replace(/[\/\s:]+/g, '.')
  if (!fs.existsSync(param())) fs.mkdirSync(param())
  
  // keep track of param changings
  fs.writeFile(
    param(time) + '.json', 
    JSON.stringify(memomap), 
    function (err) {
      if (err) throw err
    })
}

function createmodel () {
  return {
    filter: {},
    logpth: new logpth(runenv)
  }
}

/** end of mini section */