require('../mechina');

var border = page0.channel.borderbasket
var runenv = page0.variation
var modelr = load.calc('mdbox')
var filter = load.calc('kfilter').filter

var actvmq = broker(state).connect()
var result = actvmq.sendto(page0.channel.calibre)
var dbconn = load.link('dbconn')('development').connect()

var wheelr = streql.bind(null, process.env.WHEELR)
var dir = directory(__dirname, '..', 'page')
var fs = require('fs'), file = dir('params.json')
var memomap = paramload(), xclude = [], special

// create & assign loaded values
if (Object.keys(memomap).length) {
  print('LOADED!\n') // simple mark
  eachprop(memomap, function (dvid, model) {
    print('*** Loading values for', dvid, '\n')

    memomap[dvid] = modelcreation()
    copy(model.logmd, memomap[dvid].logmd)

    eachprop(model.filter, function (dvc, data) {
      memomap[dvid].filter[dvc] = new filter(runenv)
      copy(data, memomap[dvid].filter[dvc])
    })
  })
}

dbconn.query({
  sql: 'select ??, ??, ?? from `device_deployment`',
  values: ['deviceid', 'coordinates', 'type']
}, function (devices) {
  mapping(devices) // setup some initial data
  console.log('!!! Devices excluding', xclude.join(' '))
  actvmq.listen(border).do(processing) // real run here
})

function mapping(devices) {
  print('&&& Founding d-map for',
    devices.length, 'devices!\n')

  // get (the) special one(s) first!
  special = devices.filter(
    function (dv) {
      return streql(dv.type, 'special')
    })[0]

  if (itis.Empty(special))
    throw new Error("No special device!")
  console.log('&&& Special device:',
    special = special.deviceid)

  devices.map(
    function (dv) {
      var _id = dv.deviceid
      switch (lower(dv.type)) {
        case 'server': xclude.push(_id); break
        case 'relay':
          xclude.push(_id) // may not really want to see relays
          if (itis.Object(memomap[_id])) break
          console.log('&&& New creation for', _id)
          // new creation for the relay
          memomap[_id] = modelcreation()
          memomap[_id].logmd.devic = special
      }
    }
  )
}

function processing(data) {
  var addr = memomap[data.scanner]
  if (!itis.Object(addr)) return // need handle when new one comes in
  if (xclude.has(data.target)) return // need to specify what's excluded

  if (!addr.filter[data.target]) 
  // each transmission makes use of one filter process 
    addr.filter[data.target] = new filter(runenv);
  
  // just filter it! no care of checked filter or not?
  data.filtered = addr.filter[data.target].value(data.rssi)
  var value = data[runenv.filter ? 'filtered' : 'rssi']

  print( // start of the log line
    clock.shortstamp(new Date(data.time)),
    data.scanner, data.target, data.rssi, value, ''
  )

  // step#1: calibration, when target is the special one
  if (streql(special, data.target)) {
    var dt = addr.timing.click() // get the time difference
    // `addr.logmd.initx` is used like a switch here
    // if (!addr.logmd.initx && dt < addr.lapse) {
    if (itis.Empty(addr.logmd.initx) && wheelr('init')) {
      addr.logmd.base(value, special) // 'A' basing from received rssi
      if (!!addr.logmd.initx) { // when it is initialised
        print('(' + addr.timing.duration + ')')
        addr.timing.stopwatch() // reset time watcher
      } 
    // } else if (addr.timing.duration < addr.envtime)
    // when collect during the time of env. characterizing 
    } 
    var _tsl = data.scanner.slice(0, wheelr.length)
    if (wheelr('env') || wheelr(_tsl))
      data.pattern = addr.logmd.characterize(value, special);
  } // runs everytime the special is seen as target

  savememo() // params saving here 6( ^ . ^ )
  // step#2: distance calculation
  data.distance = +addr.logmd.distance(value)

  // if (!isNaN(data.distance)) {
  //   data.distance += Math.random()*0.1 + 0.1
  //   print(data.distance) // see what is calculated
  //   result.letter(data) // one routine is finished
  // }; print('\n')

  if (isNaN(data.distance)) 
    delete data.distance;
  else {
    data.distance += Math.random()*0.1 + 0.1
    print('d=', data.distance)
  }
  result.letter(data), print('\n')
}

/** mini functional parts */

function modelcreation() {
  return {
    filter: {},
    logmd: new modelr(runenv),
    timing: clock().stopwatch(),
    // time data in minutes
    // timelapse between actions: A-base & characterization
    lapse: clock.minutes(runenv.timelapse || 1),
    // duration for rssi characterizing for env
    envtime: clock.minutes(runenv.envtime || 2)
  }
}

function paramload() {
  try {
    print('*** Finding old params... ')
    return require(file)
  } catch (e) {
    // console.log('actual error:', e)
    print('Nothing loaded!\n')
    return {}
  }
}

function savememo() {
  // print('saving... ')
  fs.writeFile(file,
    JSON.stringify(memomap),
    function (err) {
      if (err) throw err
      // print('Params saved!\n')
    })
}

// function timesave() {
//   var param = dir.bind(null, 'param')
//   var time = clock.shortstamp()

//   time = time.replace(/[\/\s:]+/g, '.')
//   if (!fs.existsSync(param())) fs.mkdirSync(param())

//   // keep track of param changings
//   fs.writeFile(
//     param(time) + '.json',
//     JSON.stringify(memomap),
//     function (err) {
//       if (err) throw err
//     })
// }

/** end of mini section */